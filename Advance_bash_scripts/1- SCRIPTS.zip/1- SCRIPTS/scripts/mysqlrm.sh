#!/bin/bash
BACKUP=/Backup/MySQL_Backup
rm -rf $BACKUP
exit 0
